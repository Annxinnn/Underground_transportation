import matplotlib.pyplot as plt
import numpy as np


def map2npy(filename):
    
    #首先处理npy文件
    try:
        grid_map=np.load(filename)
        meetings = [(np.random.randint(0,grid_map.shape[0]),np.random.randint(0,grid_map.shape[1])),(np.random.randint(0,grid_map.shape[0]),np.random.randint(0,grid_map.shape[1]))]
        cars=[(np.random.randint(0,grid_map.shape[0]),np.random.randint(0,grid_map.shape[1])),(np.random.randint(0,grid_map.shape[0]),np.random.randint(0,grid_map.shape[1]))]
        
        #随机地图结果合规
        for i in range(len(cars)):
            grid_map[cars[i][0]][cars[i][1]] = 0
        for i in range(1, len(meetings)):
            grid_map[meetings[i][0]][meetings[i][1]] = 0
        return grid_map,meetings,cars
    except:
        pass
    
    data=[]
    meetings=[]
    cars=[]
    with open(filename,"r") as f:
        lines=f.readlines()
        for i in range(len(lines)):
            ld=[]
            for j in range(len(list(lines[i]))):
                if(lines[i][j]=="."):
                    ld.append(1)
                if(lines[i][j]=="*"):
                    ld.append(0)
                if(lines[i][j]=="&"):
                    ld.append(0)
                    meetings.append((j,i))
                if(lines[i][j]=="c"):
                    ld.append(0)
                    cars.append((j,i))
            data.append(ld.copy())
    grid_map=np.array(data).T

    return grid_map,meetings,cars