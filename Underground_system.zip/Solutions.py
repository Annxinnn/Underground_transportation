import heapq
import math
import matplotlib.pyplot as plt
import numpy as np


# 栅格地图参数设置
MAP_WIDTH = 80  # 地图宽度（单位：栅格）
MAP_HEIGHT =40  # 地图高度


# 定义节点类
class Node:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.g = float('inf')
        self.h = 0
        self.f = float('inf')
        self.parent = None

    def __lt__(self, other):
        return self.f < other.f
# 改进A*算法实现
def improved_a_star(grid, start, goal):
    # 初始化开放列表（二叉堆）和封闭列表
    open_heap = []
    closed_set = set()

    # 创建起点和终点节点
    start_node = Node(*start)
    start_node.g = 0
    start_node.h = heuristic(start, goal)
    start_node.f = start_node.g + start_node.h
    goal_node = Node(*goal)

    heapq.heappush(open_heap, start_node)

    # 节点生成器（简化版，实际需处理边界）
    def get_neighbors(node):
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]  # 四邻域
        neighbors = []
        for dx, dy in directions:
            nx, ny = node.x + dx, node.y + dy
            if 0 <= nx < MAP_WIDTH and 0 <= ny < MAP_HEIGHT:
                if grid[nx][ny] == 0:  # 排除障碍物
                    neighbors.append(Node(nx, ny))
        return neighbors

    while open_heap:
        current = heapq.heappop(open_heap)

        # 到达终点
        if (current.x, current.y) == (goal_node.x, goal_node.y):
            path = []
            while current:
                path.append((current.x, current.y))
                current = current.parent
            return path[::-1]  # 反转路径

        closed_set.add((current.x, current.y))

        for neighbor in get_neighbors(current):
            if (neighbor.x, neighbor.y) in closed_set:
                continue

            # 计算新代价（考虑重载/空载能耗差异）
            tentative_g = current.g + movement_cost(current, neighbor)

            # 检查节点是否在开放列表中
            in_open = False
            for n in open_heap:
                if (n.x, n.y) == (neighbor.x, neighbor.y):
                    in_open = True
                    if tentative_g < n.g:
                        n.g = tentative_g
                        n.f = n.g + n.h
                        n.parent = current
                        heapq.heapify(open_heap)  # 更新堆结构
                    break

            if not in_open:
                neighbor.g = tentative_g
                neighbor.h = heuristic((neighbor.x, neighbor.y), goal)
                neighbor.f = neighbor.g + neighbor.h
                neighbor.parent = current
                heapq.heappush(open_heap, neighbor)

    return None  # 无路径
# 启发式函数（欧氏距离）
def heuristic(a, b):
    return math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2)
# 移动成本（根据论文参数设置）
def movement_cost(from_node, to_node, BASE_COST=10,LOAD_COST=90,UN_LOAD_COST=50):
    # 假设重载时能耗系数为90，空载为50（简化处理）
    is_loaded = True  # 可根据路径状态调整
    base_cost = BASE_COST  # 固定运输成本（元/栅格）
    energy_cost = LOAD_COST if is_loaded else UN_LOAD_COST
    return base_cost + energy_cost  # 总运输成本